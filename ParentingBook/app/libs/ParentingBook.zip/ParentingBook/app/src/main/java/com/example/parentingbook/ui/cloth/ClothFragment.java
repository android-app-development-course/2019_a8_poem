package com.example.parentingbook.ui.cloth;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.viewpager.widget.ViewPager;

import com.example.parentingbook.Articles;
import com.example.parentingbook.ArticlesAdapter;
import com.example.parentingbook.LoopViewAdapter;
import com.example.parentingbook.R;
import com.example.parentingbook.WebViewActivity;
import com.example.parentingbook.ui.pagerOnClickListener;

import java.util.ArrayList;
import java.util.List;

public class ClothFragment extends Fragment {

    private ClothViewModel clothViewModel;
    //ListView文章列表
    private List<Articles> articlesList=new ArrayList<Articles>();
    //轮播图实现
    private ViewPager viewPager;  //轮播图模块
    private int[] myImg;     //轮播图
    private int[] myImg_id;  //轮播图对应的ID
    private String[] title;
    private ArrayList<ImageView> myImgList;  //轮播图
    private LinearLayout loop_dot;
    private TextView loop_title;
    private int previousSelectedPosition = 0;
    boolean isRunning = false;



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        clothViewModel =
                ViewModelProviders.of(this).get(ClothViewModel.class);
        View root = inflater.inflate(R.layout.fragment_cloth, container, false);

        //类实现、ListView与适配器
        iniArticlesList();
        ListView lv=(ListView)root.findViewById(R.id.cloth_main_articles);
        ArticlesAdapter myadapter=new ArticlesAdapter(getActivity(),R.layout.list_item,articlesList);
        lv.setAdapter(myadapter);

        //轮播图实现
        iniLoopView();

        //添加点击事件
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Articles art=articlesList.get(position);
                //跳转到指定链接
                Intent intent = new Intent(getActivity(), WebViewActivity.class);
                //将数据存入Intent
                intent.putExtra("href",art.getHref());
                startActivity(intent);
            }
        });

        return root;
    }

    //文章
    private void iniArticlesList(){
        Articles a_1=new Articles("yym不为人知的故事",R.drawable.yym,
                "https://www.qbb6.com/article/rJgIPOckJ?src=pnews&trackid=509860105&trackinfo=hhH9LrIFt4f&source=qbb&versioncode=440&env=prod&from=singlemessage");
        articlesList.add(a_1);
        Articles a_2=new Articles("Yui",R.drawable.yui,"https://www.baidu.com/");
        articlesList.add(a_2);
        Articles a_3=new Articles("Mio",R.drawable.mio,"https://www.bilibili.com/");
        articlesList.add(a_3);
        Articles a_4=new Articles("Ritsu",R.drawable.ritsu,"https://www.baidu.com/");
        articlesList.add(a_4);
        Articles a_5=new Articles("Azusa",R.drawable.azusa,"https://www.baidu.com/");
        articlesList.add(a_5);
        Articles a_6=new Articles("Tsumugi",R.drawable.tsumugi,"https://www.baidu.com/");
        articlesList.add(a_6);
        Articles a_7=new Articles("Neko",R.drawable.neko,"https://www.baidu.com/");
        articlesList.add(a_7);
        Articles a_8=new Articles("秃头披风侠",R.drawable.tutou,"https://www.baidu.com/");
        articlesList.add(a_8);
        Articles a_9=new Articles("阿七",R.drawable.aseven,"https://www.baidu.com/");
        articlesList.add(a_9);
        Articles a_10=new Articles("君莫笑",R.drawable.yexiu,"https://www.baidu.com/");
        articlesList.add(a_10);
    }

    private void iniLoopView(){
        viewPager=(ViewPager)getView().findViewById(R.id.loopview);
        loop_dot = (LinearLayout)getView().findViewById(R.id.loop_dot);
        loop_title = (TextView)getView().findViewById(R.id.loop_title);

        //图片
        myImg=new int[]{
                R.drawable.yui,
                R.drawable.mio,
                R.drawable.ritsu,
                R.drawable.azusa,
                R.drawable.tsumugi
        };

        //图片ID
        myImg_id=new int[]{
                R.id.pager_img1,
                R.id.pager_img2,
                R.id.pager_img3,
                R.id.pager_img4,
                R.id.pager_img5
        };

        //标题
        title=new String[]{
                "Yui",
                "Mio",
                "Ritsu",
                "Azusa",
                "Tsumugi"
        };

        //初始化轮播图
        myImgList=new ArrayList<ImageView>();

        ImageView imageView;
        View dotView;
        LinearLayout.LayoutParams layoutParams;//LayoutParams 的作用是：子控件告诉父控件，自己要如何布局

        for(int i=0;i<myImg.length;i++){
            //设置每一个轮播图的属性并且添加到List中
            imageView = new ImageView(getActivity());
            imageView.setBackgroundResource(myImg[i]);
            imageView.setId(myImg_id[i]);
            imageView.setOnClickListener(new pagerOnClickListener(getActivity().getApplicationContext()));
            myImgList.add(imageView);
            //设置对应的dot
            dotView = new View(getActivity());
            dotView.setBackgroundResource(R.drawable.dot);
            layoutParams = new LinearLayout.LayoutParams(10,10);//宽高都为10
            if(i!=0){
                //dot之间的外间距为10
                layoutParams.leftMargin=10;
            }
            //设置默认所有都不可用
            dotView.setEnabled(false);
            loop_dot.addView(dotView,layoutParams);
        }//for

        //初始图片启动
        loop_dot.getChildAt(0).setEnabled(true);
        loop_title.setText(title[0]);
        previousSelectedPosition=0;

        //适配器
        viewPager.setAdapter(new LoopViewAdapter(myImgList));

        //循环
        int m = (Integer.MAX_VALUE / 2) % myImgList.size();
        int currentPosition = Integer.MAX_VALUE / 2 - m;
        viewPager.setCurrentItem(currentPosition);

        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                // 监听组件的滑动。position为当前页面的索引，positionOffset为当前页面偏移的百分比
                // positionOffsetPixels为当前页面偏移的像素位置
            }

            @Override
            public void onPageSelected(int position) {
                //监听组件的页面变化。position为当前页面的索引
                //页面变化时，使上一个页面无效，新页面有效
                int newPosition=position % myImgList.size();
                loop_title.setText(title[newPosition]);
                loop_dot.getChildAt(previousSelectedPosition).setEnabled(false);
                loop_dot.getChildAt(newPosition).setEnabled(true);
                previousSelectedPosition = newPosition;
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                /*监听组件的滑动状态变化。state有3种取值：
                ViewPager.SCROLL_STATE_IDLE = 0; 空闲状态，也是初始状态，此时组件是静止的。
                ViewPager.SCROLL_STATE_DRAGGING = 1; 滑动状态，当手指在屏幕上滑动组件时的状态。
                ViewPager.SCROLL_STATE_SETTLING = 2; 滑动后自然沉降的状态，当手指离开屏幕后
                组件继续滑动时的状态。*/
            }
        });

        //轮询
        new Thread(){

            public void run() {
                isRunning=true;
                while(isRunning){
                    try{
                        Thread.sleep(5000);
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }

                    //自动播放下一条
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            viewPager.setCurrentItem(viewPager.getCurrentItem()+1);
                        }
                    });

                }
            }
        }.start();

    }

}