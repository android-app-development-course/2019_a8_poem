package com.example.parentingbook;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import java.util.ArrayList;

public class LoopViewAdapter extends PagerAdapter {
    //轮播图集合
    private ArrayList<ImageView> loop_image_list;
    public LoopViewAdapter(ArrayList<ImageView> mImgList){
        loop_image_list = mImgList;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        // container: 容器: ViewPager
        // position: 当前要显示条目的位置 0 -> 4
        //newPosition = position % 5
        int newPosition = position % loop_image_list.size();
        ImageView img = loop_image_list.get(newPosition);
        // 把View对象添加到container中
        container.addView(img);
        // 把View对象返回给框架, 适配器
        return img;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View)object);
    }

    @Override
    public int getCount() {
        //返回一个巨大的值，实现无限循环
        return Integer.MAX_VALUE;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view==object;
    }
}
