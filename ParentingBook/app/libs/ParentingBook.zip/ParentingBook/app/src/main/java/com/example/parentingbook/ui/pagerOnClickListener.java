package com.example.parentingbook.ui;

import android.content.Context;
import android.view.View;

import com.example.parentingbook.R;

public class pagerOnClickListener implements View.OnClickListener{
    Context mContext;
    public pagerOnClickListener(Context myContext){
        this.mContext=myContext;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.pager_img1:
            case R.id.pager_img2:
            case R.id.pager_img3:
            case R.id.pager_img4:
            case R.id.pager_img5:

                break;
        }
    }
}
