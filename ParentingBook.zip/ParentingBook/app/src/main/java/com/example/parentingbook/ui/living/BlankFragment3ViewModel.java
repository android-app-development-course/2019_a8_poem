package com.example.parentingbook.ui.living;

import androidx.lifecycle.ViewModel;

public class BlankFragment3ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
