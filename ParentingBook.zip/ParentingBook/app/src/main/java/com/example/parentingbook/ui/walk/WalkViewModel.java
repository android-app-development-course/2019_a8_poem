package com.example.parentingbook.ui.walk;

import androidx.lifecycle.ViewModel;

public class WalkViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
