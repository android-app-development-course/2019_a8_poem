package com.example.parentingbook.ui.walk;

import androidx.lifecycle.ViewModel;

public class WalkFragment2ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
